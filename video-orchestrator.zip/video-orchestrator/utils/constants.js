module.exports = {
  STATUS: {
    PENDING: 'pending',
    PROCESSING: 'processing',
    COMPLETED: 'completed',
    FAILED: 'failed'
  },
  SERVER_STATUS: {
    READY: 'ready',
    BUSY: 'busy',
    OFFLINE: 'offline'
  }
}; 