const express = require('express');
const router = express.Router();
const Job = require('../models/Job');
const logger = require('../utils/logger');

// Create a new job
router.post('/', async (req, res) => {
  try {
    const { companyName, websiteUrl, overlayVideo } = req.body;
    
    // Validate input
    if (!websiteUrl || !overlayVideo) {
      return res.status(400).json({ 
        error: 'Missing required fields: websiteUrl, overlayVideo' 
      });
    }
    
    const job = await Job.create({
      companyName: companyName || 'Unnamed Company',
      websiteUrl,
      overlayVideo
    });
    
    logger.info(`Created new job: ${job.job_id}`);
    res.status(201).json(job);
  } catch (error) {
    logger.error('Error creating job:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get job by ID
router.get('/:jobId', async (req, res) => {
  try {
    const job = await Job.getById(req.params.jobId);
    
    if (!job) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    res.json(job);
  } catch (error) {
    logger.error(`Error getting job ${req.params.jobId}:`, error);
    res.status(500).json({ error: error.message });
  }
});

// Update job status
router.put('/:jobId/status', async (req, res) => {
  try {
    const { status, downloadUrl, error } = req.body;
    
    // Validate input
    if (!status || !['processing', 'completed', 'failed'].includes(status)) {
      return res.status(400).json({ 
        error: 'Invalid status. Must be: processing, completed, or failed' 
      });
    }
    
    // Additional data based on status
    const data = {};
    if (status === 'completed' && downloadUrl) {
      data.downloadUrl = downloadUrl;
    } else if (status === 'failed' && error) {
      data.error = error;
    }
    
    const job = await Job.updateStatus(req.params.jobId, status, data);
    
    if (!job) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    logger.info(`Updated job ${req.params.jobId} status to ${status}`);
    res.json(job);
  } catch (error) {
    logger.error(`Error updating job ${req.params.jobId}:`, error);
    res.status(500).json({ error: error.message });
  }
});

// Get pending jobs
router.get('/queue/pending', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const jobs = await Job.getPendingJobs(limit);
    res.json(jobs);
  } catch (error) {
    logger.error('Error getting pending jobs:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router; 