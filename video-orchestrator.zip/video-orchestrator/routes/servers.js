const express = require('express');
const router = express.Router();
const Server = require('../models/Server');
const logger = require('../utils/logger');

// Register a new server
router.post('/', async (req, res) => {
  try {
    const { serviceName, accountEmail, url, dailyLimit } = req.body;
    
    // Validate input
    if (!serviceName || !accountEmail || !url) {
      return res.status(400).json({ 
        error: 'Missing required fields: serviceName, accountEmail, url' 
      });
    }
    
    const server = await Server.create({
      serviceName,
      accountEmail,
      url,
      dailyLimit: dailyLimit || 20
    });
    
    logger.info(`Registered new server: ${serviceName} (${url})`);
    res.status(201).json(server);
  } catch (error) {
    logger.error('Error registering server:', error);
    res.status(500).json({ error: error.message });
  }
});

// Update server status
router.put('/:id/status', async (req, res) => {
  try {
    const { status, healthScore } = req.body;
    
    // Validate input
    if (!status || !['ready', 'busy', 'offline'].includes(status)) {
      return res.status(400).json({ 
        error: 'Invalid status. Must be: ready, busy, or offline' 
      });
    }
    
    const server = await Server.updateStatus(req.params.id, status, {
      healthScore: healthScore || 100
    });
    
    if (!server) {
      return res.status(404).json({ error: 'Server not found' });
    }
    
    logger.info(`Updated server ${req.params.id} status to ${status}`);
    res.json(server);
  } catch (error) {
    logger.error(`Error updating server ${req.params.id}:`, error);
    res.status(500).json({ error: error.message });
  }
});

// Get available servers
router.get('/available', async (req, res) => {
  try {
    const servers = await Server.getAvailableServers();
    res.json(servers);
  } catch (error) {
    logger.error('Error getting available servers:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router; 