# Video Orchestrator

Central orchestration service for distributed video processing across multiple free-tier hosting providers.

## Overview

This service coordinates video processing jobs across a network of processing nodes. It:

- Manages a queue of video processing jobs
- Distributes jobs to available processing servers
- Tracks server health and availability
- Manages daily processing limits
- Provides API endpoints for job management

## Setup

### Prerequisites

- Node.js 14+
- PostgreSQL database (Supabase free tier recommended)
- GitHub account

### Local Development

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create a `.env` file based on `env.example`
4. Run the service:
   ```
   npm run dev
   ```

### Database Setup

Run these SQL commands in your Supabase SQL Editor to create the necessary tables:

```sql
-- Table for tracking processing servers
CREATE TABLE servers (
  id SERIAL PRIMARY KEY,
  service_name VARCHAR(50) NOT NULL,
  account_email VARCHAR(255) NOT NULL,
  url VARCHAR(255) NOT NULL,
  status VARCHAR(50) DEFAULT 'ready',
  jobs_processed INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  last_ping TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  health_score INTEGER DEFAULT 100,
  daily_limit INTEGER DEFAULT 20,
  daily_used INTEGER DEFAULT 0
);

-- Table for tracking jobs
CREATE TABLE jobs (
  job_id VARCHAR(50) PRIMARY KEY,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  company_name VARCHAR(255),
  website_url VARCHAR(255),
  overlay_video VARCHAR(255),
  assigned_server INTEGER REFERENCES servers(id),
  processing_started TIMESTAMP,
  processing_completed TIMESTAMP,
  download_url VARCHAR(255),
  error_message TEXT
);
```

### Deployment to Render.com

1. Push the code to GitHub
2. Log in to Render.com
3. Create a new Web Service
4. Connect to your GitHub repository
5. Configure:
   - Name: video-orchestrator
   - Environment: Node
   - Build Command: `npm install`
   - Start Command: `node index.js`
   - Environment Variables: Add all variables from your `.env` file

## API Endpoints

### Jobs

- `POST /api/jobs` - Create a new job
- `GET /api/jobs/:jobId` - Get job by ID
- `PUT /api/jobs/:jobId/status` - Update job status
- `GET /api/jobs/queue/pending` - Get pending jobs

### Servers

- `POST /api/servers` - Register a new server
- `PUT /api/servers/:id/status` - Update server status
- `GET /api/servers/available` - Get available servers

## Architecture

- **Models**: Database interaction layer
- **Routes**: API endpoints
- **Services**: Business logic (distributor, scheduler)
- **Utils**: Utility functions and constants

## Next Steps

After deploying this orchestrator:

1. Deploy processing nodes on other free hosting platforms
2. Register each node with this orchestrator
3. Start submitting jobs via the API 