require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { v4: uuidv4 } = require('uuid');
const jobsRoutes = require('./routes/jobs');
const serversRoutes = require('./routes/servers');
const scheduler = require('./services/scheduler');
const logger = require('./utils/logger');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// API key validation middleware
const validateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey || apiKey !== process.env.API_KEY) {
    return res.status(401).json({ error: 'Invalid API key' });
  }
  
  next();
};

// Basic routes
app.get('/', (req, res) => {
  res.json({ message: 'Video Orchestrator API' });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

// Apply API routes with validation
app.use('/api/jobs', validateApiKey, jobsRoutes);
app.use('/api/servers', validateApiKey, serversRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message
  });
});

// Start the server
app.listen(PORT, () => {
  logger.info(`Orchestrator running on port ${PORT}`);
  
  // Start the scheduler
  scheduler.start().catch(err => {
    logger.error('Failed to start scheduler:', err);
  });
});

module.exports = app; 