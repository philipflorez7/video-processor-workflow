const Job = require('../models/Job');
const Server = require('../models/Server');
const fetch = require('node-fetch');
const logger = require('../utils/logger');

class Distributor {
  static async assignJobs() {
    try {
      // Get pending jobs
      const pendingJobs = await Job.getPendingJobs(20);
      if (pendingJobs.length === 0) {
        return { assigned: 0 };
      }
      
      // Get available servers
      const availableServers = await Server.getAvailableServers();
      if (availableServers.length === 0) {
        logger.warn('No available servers to process jobs');
        return { assigned: 0 };
      }
      
      let assignedCount = 0;
      
      // Assign jobs to servers
      for (const job of pendingJobs) {
        // Round-robin server selection
        const serverIndex = assignedCount % availableServers.length;
        const server = availableServers[serverIndex];
        
        try {
          // Update job status
          await Job.updateStatus(job.job_id, 'processing', { 
            serverId: server.id 
          });
          
          // Update server job count
          await Server.incrementJobCount(server.id);
          
          // Send job to server
          await this.sendJobToServer(server, job);
          
          assignedCount++;
          
          // If server reaches daily limit, remove from available servers
          if (server.daily_used + 1 >= server.daily_limit) {
            availableServers.splice(serverIndex, 1);
            if (availableServers.length === 0) break;
          }
        } catch (error) {
          logger.error(`Failed to assign job ${job.job_id} to server ${server.id}:`, error);
          await Job.updateStatus(job.job_id, 'failed', { 
            error: `Failed to assign to server: ${error.message}` 
          });
        }
      }
      
      return { assigned: assignedCount };
    } catch (error) {
      logger.error('Error in job distribution:', error);
      return { assigned: 0, error: error.message };
    }
  }
  
  static async sendJobToServer(server, job) {
    try {
      // Construct server's job processing endpoint
      const endpoint = `${server.url}/api/process-job`;
      
      // Send the job data to the server
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': process.env.API_KEY
        },
        body: JSON.stringify({
          jobId: job.job_id,
          websiteUrl: job.website_url,
          companyName: job.company_name,
          overlayVideo: job.overlay_video
        })
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Server responded with ${response.status}: ${error}`);
      }
      
      logger.info(`Job ${job.job_id} sent to server ${server.id} (${server.url})`);
      return true;
    } catch (error) {
      logger.error(`Error sending job to server: ${error.message}`);
      throw error;
    }
  }
}

module.exports = Distributor; 