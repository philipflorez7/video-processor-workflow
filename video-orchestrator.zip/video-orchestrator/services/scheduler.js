const Distributor = require('./distributor');
const Server = require('../models/Server');
const logger = require('../utils/logger');

class Scheduler {
  static async start() {
    logger.info('Starting job scheduler');
    
    // Reset daily counters at midnight
    this.scheduleDailyReset();
    
    // Run distributor every minute
    setInterval(async () => {
      logger.info('Running scheduled job distribution');
      try {
        const result = await Distributor.assignJobs();
        logger.info(`Assigned ${result.assigned} jobs to servers`);
      } catch (error) {
        logger.error('Error in scheduled distribution:', error);
      }
    }, 60000);
  }
  
  static scheduleDailyReset() {
    const now = new Date();
    const night = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + 1, // tomorrow
      0, 0, 0 // midnight
    );
    
    const msUntilMidnight = night.getTime() - now.getTime();
    
    // Schedule the reset
    setTimeout(async () => {
      try {
        logger.info('Resetting daily server usage counters');
        await Server.resetDailyCounts();
        
        // Schedule the next day's reset
        this.scheduleDailyReset();
      } catch (error) {
        logger.error('Error resetting daily counters:', error);
      }
    }, msUntilMidnight);
    
    logger.info(`Daily reset scheduled in ${Math.round(msUntilMidnight / 1000 / 60)} minutes`);
  }
}

module.exports = Scheduler; 