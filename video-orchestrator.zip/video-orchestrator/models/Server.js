const db = require('../config/db');

class Server {
  static async create(data) {
    const query = `
      INSERT INTO servers (
        service_name, account_email, url, status, daily_limit
      ) VALUES ($1, $2, $3, $4, $5) RETURNING *
    `;
    const values = [
      data.serviceName,
      data.accountEmail,
      data.url,
      data.status || 'ready',
      data.dailyLimit || 20
    ];
    
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async getById(id) {
    const query = 'SELECT * FROM servers WHERE id = $1';
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async getAvailableServers() {
    const query = `
      SELECT * FROM servers 
      WHERE is_active = true 
      AND status = 'ready' 
      AND daily_used < daily_limit
      ORDER BY daily_used ASC, health_score DESC
    `;
    const result = await db.query(query);
    return result.rows;
  }

  static async updateStatus(id, status, data = {}) {
    const query = `
      UPDATE servers SET 
        status = $2,
        last_ping = CURRENT_TIMESTAMP,
        health_score = $3
      WHERE id = $1 RETURNING *
    `;
    const values = [id, status, data.healthScore || 100];
    
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async incrementJobCount(id) {
    const query = `
      UPDATE servers SET 
        jobs_processed = jobs_processed + 1,
        daily_used = daily_used + 1
      WHERE id = $1 RETURNING *
    `;
    
    const result = await db.query(query, [id]);
    return result.rows[0];
  }

  static async resetDailyCounts() {
    const query = 'UPDATE servers SET daily_used = 0';
    return db.query(query);
  }
}

module.exports = Server; 