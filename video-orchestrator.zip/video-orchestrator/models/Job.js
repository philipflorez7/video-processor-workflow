const db = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class Job {
  static async create(data) {
    const jobId = uuidv4();
    const query = `
      INSERT INTO jobs (
        job_id, status, company_name, website_url, overlay_video
      ) VALUES ($1, $2, $3, $4, $5) RETURNING *
    `;
    const values = [
      jobId,
      'pending',
      data.companyName,
      data.websiteUrl,
      data.overlayVideo
    ];
    
    const result = await db.query(query, values);
    return result.rows[0];
  }

  static async getById(jobId) {
    const query = 'SELECT * FROM jobs WHERE job_id = $1';
    const result = await db.query(query, [jobId]);
    return result.rows[0];
  }

  static async getPendingJobs(limit = 10) {
    const query = 'SELECT * FROM jobs WHERE status = $1 ORDER BY created_at ASC LIMIT $2';
    const result = await db.query(query, ['pending', limit]);
    return result.rows;
  }

  static async updateStatus(jobId, status, data = {}) {
    const updates = ['status = $2'];
    const values = [jobId, status];
    let paramCount = 3;
    
    // Add additional fields based on status
    if (status === 'processing') {
      updates.push('assigned_server = $3', 'processing_started = $4');
      values.push(data.serverId, new Date());
      paramCount = 5;
    } else if (status === 'completed') {
      updates.push('processing_completed = $3', 'download_url = $4');
      values.push(new Date(), data.downloadUrl);
      paramCount = 5;
    } else if (status === 'failed') {
      updates.push('error_message = $3');
      values.push(data.error);
      paramCount = 4;
    }
    
    const query = `
      UPDATE jobs SET ${updates.join(', ')} 
      WHERE job_id = $1 RETURNING *
    `;
    
    const result = await db.query(query, values);
    return result.rows[0];
  }
}

module.exports = Job; 